Made by Kiasaki (Frederic-Antoine Gingras)
		AND
	Dagothig (Guillaume No�l Martel)

Made as the Ludum Dare #26 entry for the jam!

Date : 29 april 2013

Have fun ! Updates comming !

Folow code evolution here https://github.com/kiasaki/ld26-jam-april2013

